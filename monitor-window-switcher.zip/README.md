# Monitor window switcher

GNOME shell extension to improve the window switcher on dual (or more) monitor setups. Can do the following:

- Shows the window switcher on the current monitor (instead on primary monitor).
- Filter windows by the monitor they are open on (instead of windows opened in all monitors).

Get it on GNOME extensions: https://extensions.gnome.org/extension/4164/monitor-window-switcher/
