## [v2](https://github.com/gedzeppelin/monitor-window-switcher/compare/v1...v2) (2021-04-25)

### Features

- **prefs:** add preferences dialog.